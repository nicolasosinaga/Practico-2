#pragma once
#define n 500
class Promedio
{private:
 double Vector[n];
 int Tamano;
 public:
	Promedio(void);
	int Get_Tamano();
	void Set_Tamano(int tam);
	double Get_Vector(int pos);
	void Set_Vector(double valor, int pos);
	double Calcular(int pos);
};

