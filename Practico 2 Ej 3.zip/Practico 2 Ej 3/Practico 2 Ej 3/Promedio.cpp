#include "StdAfx.h"
#include "Promedio.h"


Promedio::Promedio(void)
{
	Vector[n]=0;
	Tamano=0;
}
int Promedio::Get_Tamano()
{
	return Tamano;
}
void Promedio::Set_Tamano(int tam)
{
	Tamano=tam;
}
double Promedio::Get_Vector(int pos)
{
	return Vector[pos];
}
void Promedio::Set_Vector(double valor, int pos)
{
	Vector[pos]=valor;
}
double Promedio::Calcular(int pos)
{
	double s=0;
	int i=0;
	do
	{s=s+Vector[i];
	 i++;
	}while(i<=pos);
	s=s/pos;
	return s;
}